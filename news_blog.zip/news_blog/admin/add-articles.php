<?php
include('header.php');
include('db.php');

if ($_POST) {
  $cat_id = $_POST['cat_id'];
  $articles_name = $_POST['articles_name'];
  $articles_description = $_POST['articles_description'];

  $image=$_FILES['image']['name'];

move_uploaded_file($_FILES['image']['tmp_name'], 'image/'.$image);

  echo $ins = "INSERT INTO articles (
    cat_id,
    articles_name,
    articles_description,
    image
  )VALUES(
  '$cat_id',
  '$articles_name',
  '$articles_description',
  '$image'
  )";

  if(mysqli_query($conn,$ins) === TRUE){
    $message =  "New Recorded created successfully";
  }else{
    echo "Error";
  }
}
?>



      <div class="main-sidebar sidebar-style-2">
        <?php
          include('sidebar.php');
        ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12 col-md-12 col-lg-12">
                <form method="POST" action="" enctype="multipart/form-data">
                <div class="card">
                  <div class="card-header">
                    <h4 class="text-center">ADD ARTICLES</h4>
                  </div>
                  <?php if (isset($message)): ?>
                    <div class="alert alert-success">
                      <?php echo $message ?>
                    </div>
                  <?php endif; ?>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Category Name</label>
                      <select name="cat_id" class="form-control">
                        <option>Select Category</option>

                        <?php
                        $sel = "SELECT * FROM category";
                        $qry = mysqli_query($conn,$sel);
                        while($rows = mysqli_fetch_array($qry)){
                        ?>
                        <option value="<?php echo $rows['id']?>"><?php echo $rows['cat_name']?></option>
                        <?php 
                          }
                        ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label>Articles Name</label>
                      <input type="text" class="form-control" name="articles_name">
                    </div>

                    <div class="form-group">
                      <label>Articles Description</label>
                      <textarea name="articles_description" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                      <label>Articles Image</label>
                      <input type="file" class="form-control" name="image">
                    </div>
                  </div>
                  
                  <div class="card-footer text-right">
                    <button class="btn btn-primary mr-1" type="submit">Submit</button>
                  </div>
                </div>
                </form>
              </div>
            </div>
          </div>
        </section>
      </div>
<?php
include('footer.php');
?>
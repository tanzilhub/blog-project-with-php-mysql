<?php
include('db.php');

// Get the comment ID and current status from the URL
$id = $_GET['id'];
$status = $_GET['status'];

// Toggle the status
$new_status = ($status == 'active') ? 'inactive' : 'active';

// Update the status in the database
$update_query = "UPDATE comments SET status='$new_status' WHERE id='$id'";
mysqli_query($conn, $update_query);

// Redirect back to the comments page
header('Location: view-comments.php');
// exit();
?>

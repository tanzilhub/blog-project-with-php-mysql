<?php
include('header.php');
?>
      <div class="main-sidebar sidebar-style-2">
       <?php
include('sidebar.php');
       ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <h2>Dashboard</h2>
        </section>
      </div>
       <?php
include('footer.php');
       ?>
<?php
include('header.php');
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

 // $id = $_POST['id'];
 $cat_name = $_POST['cat_name'];
 $cat_description = $_POST['cat_description'];


 $upd = "UPDATE category SET 
 cat_name='$cat_name', 
 cat_description='$cat_description' 
 WHERE id='".$_GET['id']."'";

  if(mysqli_query($conn,$upd) === TRUE){
    $message =  "Record updated successfully";
  }else{
    echo "Error";
  }
}

$sel = "SELECT * FROM category where id='".$_GET['id']."'";
$qry = mysqli_query($conn,$sel);
$rs = mysqli_fetch_array($qry);
?>



      <div class="main-sidebar sidebar-style-2">
        <?php
          include('sidebar.php');
        ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12 col-md-12 col-lg-12">
                <form method="POST" action="">
                <div class="card">
                  <div class="card-header">
                    <h4 class="text-center">EDIT/UPDATE CATEGORY</h4>
                  </div>

                  <?php if (isset($message)): ?>
                    <div class="alert alert-success">
                      <?php echo $message ?>
                    </div>
                  <?php endif; ?>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Category Name</label>
                      <input type="text" class="form-control" name="cat_name" value="<?php echo $rs['cat_name']?>">
                    </div>

                    <div class="form-group">
                      <label>Category Description</label>
                      <input type="text" class="form-control" name="cat_description" value="<?php echo $rs['cat_description']?>">
                    </div>
                  </div>
                  
                  <div class="card-footer text-right">
                    <button class="btn btn-primary mr-1" type="submit">UPDATE</button>
                  </div>
                </div>
                </form>
              </div>
            </div>
          </div>
        </section>
      </div>
<?php
include('footer.php');
?>
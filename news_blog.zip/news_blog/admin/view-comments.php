<?php
include('header.php');
include('db.php');

?>
      <div class="main-sidebar sidebar-style-2">
        <?php
          include('sidebar.php');
        ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>View Comments</h4>
                    <div class="card-header-form">
                      <form>
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search">
                          <div class="input-group-btn">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <tr>
                          <th></th>
                          <th>POST ID</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Message</th>
                          <th>Status</th>
                          <th>DELETE</th>
                        </tr>
                        <?php
                          $sel = "SELECT * FROM comments";
                          $qry = mysqli_query($conn,$sel);
                          while ($row = mysqli_fetch_array($qry)) {
                          ?>

                        <tr>
                          <td></td>
                          <td><?php echo $row['post_id'];?></td>
                          <td><?php echo $row['your_name'];?></td>
                          <td><?php echo $row['email'];?></td>
                          <td><?php echo $row['message'];?></td>
                          <td>
  <a href="toggle-status.php?id=<?php echo $row['id']; ?>&status=<?php echo $row['status']; ?>" class="badge <?php echo ($row['status'] == 'active') ? 'badge-success' : 'badge-danger'; ?>">
    <?php echo $row['status']; ?>
  </a>
</td>
                          </td><td><a href="delete-comments.php?id=<?php echo $row['id']?>" class="btn btn-danger">DELETE</a></td>
                        </tr>

                        <?php
                          }
                        ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
     <?php
include('footer.php');
   ?>
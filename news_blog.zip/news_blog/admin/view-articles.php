<?php
include('header.php');
include('db.php');

?>
      <div class="main-sidebar sidebar-style-2">
        <?php
          include('sidebar.php');
        ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>View Articles</h4>
                    <div class="card-header-form">
                      <form>
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search">
                          <div class="input-group-btn">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <tr>
                          <th></th>
                          <th>Articles Name</th>
                          <th>Articles Description</th>
                          <th>Image</th>
                          <th>EDIT</th>
                          <th>DELETE</th>
                        </tr>
                        <?php
                          $sel = "SELECT * FROM articles";
                          $qry = mysqli_query($conn,$sel);
                          while ($row = mysqli_fetch_array($qry)) {
                          ?>

                        <tr>
                          <td></td>
                          <td><?php echo $row['articles_name'];?></td>
                          <td><?php echo $row['articles_description'];?></td>
                          <td>
                            <img src="image/<?php echo $row['image'];?>" height="50" width="50">
                          </td>
                          <td><a href="edit-articles.php?id=<?php echo $row['id']?>" class="btn btn-primary">Edit</a></td>
                          <td><a href="delete-articles.php?id=<?php echo $row['id']?>" class="btn btn-danger">DELETE</a></td>
                        </tr>

                        <?php
                          }
                        ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
     <?php
include('footer.php');
   ?>
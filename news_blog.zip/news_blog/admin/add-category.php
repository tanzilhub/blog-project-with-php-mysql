<?php
include('header.php');
include('db.php');

if ($_POST) {
  $cat_name = $_POST['cat_name'];
  $cat_description = $_POST['cat_description'];

  $ins = "INSERT INTO category (
    cat_name,
    cat_description
  )VALUES(
  '$cat_name',
  '$cat_description'
  )";

  if(mysqli_query($conn,$ins) === TRUE){
    $message =  "New Recorded created successfully";
  }else{
    echo "Error";
  }
}
?>



      <div class="main-sidebar sidebar-style-2">
        <?php
          include('sidebar.php');
        ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12 col-md-12 col-lg-12">
                <form method="POST" action="">
                <div class="card">
                  <div class="card-header">
                    <h4 class="text-center">ADD CATEGORY</h4>
                  </div>
                  <?php if (isset($message)): ?>
                    <div class="alert alert-success">
                      <?php echo $message ?>
                    </div>
                  <?php endif; ?>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Category Name</label>
                      <input type="text" class="form-control" name="cat_name">
                    </div>

                    <div class="form-group">
                      <label>Category Description</label>
                      <input type="text" class="form-control" name="cat_description">
                    </div>
                  </div>
                  
                  <div class="card-footer text-right">
                    <button class="btn btn-primary mr-1" type="submit">Submit</button>
                  </div>
                </div>
                </form>
              </div>
            </div>
          </div>
        </section>
      </div>
<?php
include('footer.php');
?>
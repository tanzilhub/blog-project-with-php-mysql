<?php
include('db.php');

if ($_GET) {
    // print_r($_POST);
    // $id = $_POST['id'];

    $sql = "DELETE FROM category WHERE id ='".$_GET['id']."'";

    if (mysqli_query($conn,$sql)) {
        header("location:view-category.php");
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $conn->close();
}
?>

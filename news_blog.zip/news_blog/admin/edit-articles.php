<?php
include('header.php');
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

 // $id = $_POST['id'];
 $articles_name = $_POST['articles_name'];
 $articles_description = $_POST['articles_description'];
 $image=$_FILES['image']['name'];
if ($image!='') {
            move_uploaded_file($_FILES['image']['tmp_name'],'image/'.$image);
          }
          else{
            $image=$_POST['old_image'];
          }

 $upd = "UPDATE articles SET 
 articles_name='$articles_name', 
 articles_description='$articles_description',
 image = '$image' 
 WHERE id='".$_GET['id']."'";

  if(mysqli_query($conn,$upd) === TRUE){
    $message =  "Record updated successfully";
    header("location:view-articles.php");
  }else{
    echo "Error";
  }

}

$sel = "SELECT * FROM articles where id='".$_GET['id']."'";
$qry = mysqli_query($conn,$sel);
$rs = mysqli_fetch_array($qry);
?>



      <div class="main-sidebar sidebar-style-2">
        <?php
          include('sidebar.php');
        ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12 col-md-12 col-lg-12">
                <form method="POST" action="" enctype="multipart/form-data">
                  <?php if (isset($message)): ?>
                    <div class="alert alert-success">
                      <?php echo $message ?>
                    </div>
                  <?php endif; ?>
                <div class="card">
                  <div class="card-header">
                    <h4 class="text-center">EDIT/UPDATE ARTICLES</h4>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <label>Category ID</label>
                      <select name="cat_id" class="form-control">
                        <option>Select Category</option>

                        <?php
                        $sel = "SELECT * FROM category";
                        $qry = mysqli_query($conn,$sel);
                        while($rows = mysqli_fetch_array($qry)){
                        ?>
                        <option value="<?php echo $rows['id'] ?>"
                        <?php
                          if($rows['id']==$rs['cat_id'])
                            {echo "selected";}
                        ?>
                          ><?php echo $rows['cat_name'] ?>
                        </option>
                        <?php 
                          }
                        ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label>Articles Name</label>
                      <input type="text" class="form-control" name="articles_name" value="<?php echo $rs['articles_name']?>">
                    </div>

                    <div class="form-group">
                      <label>Articles Description</label>
                      <textarea class="form-control" name="articles_description"><?php echo $rs['articles_description'];?></textarea>
                    </div>

                    <div class="form-group">
                      <label>Image</label>
                      <input type="file" name="image" value="<?php echo $rs['image'];?>" class="form-control">
                      <img src="image/<?php echo $rs['image']?>" height="50" width="50">
                      <input type="hidden" name="old_image" value="<?php echo $rs['image']; ?>">
                    </div>
                  </div>
                  
                  <div class="card-footer text-right">
                    <button class="btn btn-primary mr-1" type="submit">UPDATE</button>
                  </div>
                </div>
                </form>
              </div>
            </div>
          </div>
        </section>
      </div>
<?php
include('footer.php');
?>
<?php
include('header.php');
include('db.php');

?>
      <div class="main-sidebar sidebar-style-2">
        <?php
          include('sidebar.php');
        ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>View Category</h4>
                    <div class="card-header-form">
                      <form>
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search">
                          <div class="input-group-btn">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <tr>
                          <th></th>
                          <th>Category Name</th>
                          <th>Category Description</th>
                          <!-- <th>Status</th> -->
                          <th>EDIT</th>
                          <th>DELETE</th>
                        </tr>
                        <?php
                          $sel = "SELECT * FROM category";
                          $qry = mysqli_query($conn,$sel);
                          while ($row = mysqli_fetch_array($qry)) {
                          ?>

                        <tr>
                          <td></td>
                          <td><?php echo $row['cat_name'];?></td>
                          <td><?php echo $row['cat_description'];?></td>
                          <!-- <td>
                            <div class="badge badge-success">Active</div>
                          </td> -->
                          <td><a href="edit-category.php?id=<?php echo $row['id']?>" class="btn btn-primary">Edit</a></td>
                          <td><a href="delete-category.php?id=<?php echo $row['id']?>" class="btn btn-danger">DELETE</a></td>
                        </tr>

                        <?php
                          }
                        ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
     <?php
include('footer.php');
   ?>
<?php
include('header.php');
?>
        <!-- MAIN CONTAINER -->
        <main id="eskimo-main-container">
            <div class="container">
                <?php
                include('sidebar.php');
                ?>
                
                <!-- BLOG POSTS -->
                <!-- POST 1 -->

                <?php
                            $sel = "SELECT * FROM articles WHERE cat_id='".$_GET['cat_id']."'";
                            $qry = mysqli_query($conn,$sel);
                            while ($row = mysqli_fetch_array($qry)) {
                            ?>
                <div class="card card-horizontal">
                    <div class="card-body">
                        <div class="card-horizontal-left">
                            <!-- <div class="card-category"> -->
                                <!-- <a href="category.html">Food &amp; Drink</a> </div> -->
                            <h3 class="card-title"><a href="single-post.html"><?php echo $row['articles_name'];?></a></h3>
                            <div class="card-excerpt">
                            <p><?php echo substr($row['articles_description'], 0, 200); ?>...</p>
                            </div>
                            <div class="card-horizontal-meta">
                                <div class="eskimo-author-meta">
                                    By <a class="author-meta" href="author.html">Egemenerd</a>
                                </div>
                                <!-- <div class="eskimo-date-meta">
                                    <a href="single-post.html">May 22, 2018</a>
                                </div> -->
                                <div class="eskimo-reading-meta"><a href="post-details.php?id=<?php echo $row['id']?>">Read More</a></div>
                            </div>
                        </div>
                        <div class="card-horizontal-right" data-img="admin/image/<?php echo $row['image'];?>">
                            <a class="card-featured-img" href="single-post.html"></a>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
              
                <!-- DIVIDER -->
                <hr class="section-divider" />

               
            </div>
        </main>
<?php

include('footer.php');
?>
<?php
include('header.php');

if ($_POST) {
    $post_id = $_GET['id']; // Get the post_id from the URL
    $your_name = $_POST['your_name'];
    $email = $_POST['email'];
    $phone_no = $_POST['phone_no'];
    $message = $_POST['message'];

    $created_at = date('Y-m-d H:i:s'); // Get the current date and time

    $ins = "INSERT INTO comments (
      post_id,
      your_name,
      email,
      phone_no,
      message,
      created_at
    ) VALUES (
      '$post_id',
      '$your_name',
      '$email',
      '$phone_no',
      '$message',
      '$created_at'
    )";

    if (mysqli_query($conn, $ins) === TRUE) {
        $message = "New Record created successfully";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

$post_id = $_GET['id']; // Assuming you are getting post_id from the URL or some other source
$sel_comment = "SELECT * FROM comments WHERE post_id='$post_id' AND status='active'";
$qrys = mysqli_query($conn, $sel_comment);
?>

<!-- MAIN CONTAINER -->
<main id="eskimo-main-container">
    <div class="container">
        <?php include('sidebar.php'); ?>

        <!-- BLOG POSTS -->
        <!-- POST 1 -->
        <?php
        $sel = "SELECT * FROM articles WHERE id='" . $_GET['id'] . "'";
        $qry = mysqli_query($conn, $sel);
        $row = mysqli_fetch_array($qry);
        ?>
        <div class="card card-horizontal">
            <div class="card-body">
                <div class="card-horizontal-left">
                    <h3 class="card-title"><a href="single-post.html"><?php echo $row['articles_name']; ?></a></h3>
                    <div class="card-excerpt">
                        <p><?php echo $row['articles_description'] ?></p>
                    </div>
                    <div class="card-horizontal-meta">
                        <div class="eskimo-author-meta">
                            By <a class="author-meta" href="author.html">Egemenerd</a>
                        </div>
                        <div class="eskimo-reading-meta"><a href="post-details.php?id=<?php echo $row['id'] ?>">Read More</a></div>
                    </div>
                </div>
                <div class="card-horizontal-right" data-img="admin/image/<?php echo $row['image']; ?>">
                    <a class="card-featured-img" href="single-post.html"></a>
                </div>
            </div>
        </div>

        <!-- DIVIDER -->
        <hr class="section-divider" />
        <form method="POST" action="">
            <div class="row">
                <div class="col-12 col-lg-12">
                    <h3 class="text-center"><u>Comments</u></h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-6">
                    <p>
                        <label>Your Name</label>
                        <br>
                        <input type="text" name="your_name" id="sendername" class="form-control" required="" maxlength="50">
                    </p>
                    <p>
                        <label>Your Email</label>
                        <br>
                        <input type="email" name="email" id="senderemail" class="form-control" required="" maxlength="50">
                    </p>
                    <p>
                        <label>Phone Number</label>
                        <br>
                        <input type="text" name="phone_no" id="senderphone" class="form-control" maxlength="50">
                    </p>
                </div>
                <div class="col-12 col-lg-6">
                    <p>
                        <label>Your Message</label>
                        <br>
                        <textarea name="message" id="sendermessage" required="" class="form-control form-fixed-height"></textarea>
                    </p>
                    <button id="sendbutton" type="submit" class="btn btn-lg w-100" style="background-color: #333; border: 2px solid #333; color: #FFFFFF;">Send Message</button>
                </div>
            </div>
        </form>

        <div id="eskimo_comments_block" class="eskimo_comments_block">
            <h3 class="eskimo-title-with-border">
                <span>Comments</span>
            </h3>
            <div class="eskimo_commentlist">
                <?php if (mysqli_num_rows($qrys) > 0): ?>
                    <?php while ($rs = mysqli_fetch_array($qrys)): ?>
                        <!-- COMMENT -->
                        <div class="eskimo_comment_wrapper">
                            <div class="eskimo_comments">
                                <div class="eskimo_comment">
                                    <div class="eskimo_comment_inner">
                                        <div class="eskimo_comment_right">
                                            <div class="eskimo_comment_right_inner ">
                                                <cite class="eskimo_fn">
                                                    <?php echo $rs['your_name']; ?>
                                                </cite>
                                                <div class="eskimo_comment_links">
                                                    <i class="fa fa-clock-o"></i> <?php echo $rs['created_at']; ?>
                                                </div>
                                                <div class="eskimo_comment_text">
                                                    <p><?php echo $rs['message']; ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No active comments found for this post.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<?php
include('footer.php');
?>
